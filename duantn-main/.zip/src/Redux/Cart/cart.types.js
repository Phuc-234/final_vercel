export const CartLoading = "cart/loading";
export const CartSuccess = "cart/success";
export const CartError = "cart/error";
