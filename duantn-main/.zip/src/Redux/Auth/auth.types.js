export const LOGIN_LOADING = "auth/logging/loading";
export const LOGIN_ERROR = "auth/logging/error";
export const LOGIN_SUCCESS = "auth/logging/success";

export const LOGOUT = "auth/logout";
export const RESET = "auth/reset";
